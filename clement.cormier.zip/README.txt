J'ai trouv� le module client riche beaucoup plus facile � prendre en main que celui
de framework web. Malheureusement cela c'est invers� au cours du temps mais j'ai quand m�me
r�ussi � r�aliser la plupart des applications. Ce module �tait vraiment quelque chose
d'inconnu pour moi mais le tout premier cours a vraiment �t� efficace.

Concernant Github, j'ai eff�ctu� au minimum 1 commit par TDs et toutes mes applications sont termin�es et ou presque.
Je pense avoir bien travaill� sur ce module j'ai retravaill� sur toutes les applications que j'ai commenc� durant les TDS.

Malheureusement, j'ai eu beaucoup de probl�me avec le routage et cela m'a beaucoup d�stabilis�. 