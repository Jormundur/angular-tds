MyApp.controller("myProjectsController", function () {
    this.message = "bonjour";

});