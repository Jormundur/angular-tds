MyApp.controller("projectController", function () {
    this.message = "bonjour2";

});