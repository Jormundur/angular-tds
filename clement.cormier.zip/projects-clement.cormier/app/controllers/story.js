MyApp.controller("storyController", function () {
    this.message = "bonjour3";

});